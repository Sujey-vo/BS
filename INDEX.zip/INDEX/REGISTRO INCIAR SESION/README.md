# Formulario dinámico de registro y login  || HTML CSS JAVASCRIPT
### Video del tutorial: [https://youtu.be/XwXF_m_LBMs](https://youtu.be/XwXF_m_LBMs)

![formulario-dinamico](https://user-images.githubusercontent.com/85034795/147512236-80fe2b7d-81cb-4b18-82f3-1341b0f74953.png)
